class CreateJoinTableBankersUsers < ActiveRecord::Migration[7.1]
  def change
    create_join_table :bankers, :users do |t|
       t.index [:banker_id, :user_id]
       t.index [:user_id, :banker_id]
    end
  end
end
