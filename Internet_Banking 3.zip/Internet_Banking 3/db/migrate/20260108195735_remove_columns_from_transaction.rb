class RemoveColumnsFromTransaction < ActiveRecord::Migration[7.1]
  def change
    remove_column :transactions, :deposit, :decimal
    remove_column :transactions, :withdraw, :decimal

  end
end
