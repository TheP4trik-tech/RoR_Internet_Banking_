class CreateClientManagements < ActiveRecord::Migration[7.1]
  def change
    create_table :client_managements do |t|
      t.references :banker, null: false, foreign_key: true
      t.references :user, null: false, foreign_key: true

      t.timestamps
    end
  end
end
