class CreateBankers < ActiveRecord::Migration[7.1]
  def change
    create_table :bankers do |t|
      t.string :password
      t.string :email
      t.string :name
      t.string :surname

      t.timestamps
    end
  end
end
