class CreateLoans < ActiveRecord::Migration[7.1]
  def change
    create_table :loans do |t|
      t.integer :amount
      t.decimal :interest
      t.decimal :total_amount
      t.string :description
      t.string :status
      t.decimal :unpayed_amount

      t.timestamps
    end
  end
end
