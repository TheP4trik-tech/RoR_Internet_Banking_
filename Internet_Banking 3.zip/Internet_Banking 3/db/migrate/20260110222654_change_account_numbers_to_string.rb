class ChangeAccountNumbersToString < ActiveRecord::Migration[7.1]
  def change
    change_column :transactions, :counterparty_number, :string
    change_column :accounts, :account_number, :string
    change_column :accounts, :bank_code, :string
  end
end
