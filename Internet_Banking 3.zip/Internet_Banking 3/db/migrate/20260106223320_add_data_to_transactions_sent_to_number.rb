class AddDataToTransactionsSentToNumber < ActiveRecord::Migration[7.1]
  def change
    add_column :transactions, :sent_to, :decimal
  end
end
