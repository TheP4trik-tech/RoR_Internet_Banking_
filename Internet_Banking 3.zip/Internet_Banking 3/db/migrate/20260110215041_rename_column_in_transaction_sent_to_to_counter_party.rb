class RenameColumnInTransactionSentToToCounterParty < ActiveRecord::Migration[7.1]
  def change
    rename_column :transactions, :sent_to, :counterparty_number

  end
end
