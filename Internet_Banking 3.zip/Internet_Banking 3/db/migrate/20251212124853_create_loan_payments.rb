class CreateLoanPayments < ActiveRecord::Migration[7.1]
  def change
    create_table :loan_payments do |t|

      t.timestamps
    end
  end
end
