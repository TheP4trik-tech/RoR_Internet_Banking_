class ChangeDataTypeToAccounts < ActiveRecord::Migration[7.1]
  def change
    change_column :accounts, :account_number, :integer
    add_column :accounts, :bank_code, :integer
  end
end
