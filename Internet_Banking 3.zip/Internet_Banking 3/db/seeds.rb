
Loan.destroy_all rescue nil
Transaction.destroy_all rescue nil
ClientManagement.destroy_all rescue nil


Account.destroy_all rescue nil


User.destroy_all rescue nil
Banker.destroy_all rescue nil


Banker.create!(
  email: "admin@smudabank.com",
  password: "password",
  name: "Radim",
  surname: "Dvořák"
)

Banker.create!(
  email: "ondrej@smudabank.com",
  password: "password",
  name: "Ondřej",
  surname: "Sokol"
)

user1 = User.create!(

  name: "Jan",
  surname: "Pandulak",
  job: "Učitel",
  password: "password",
  email: "testovaci@email.cz"
)

user2 = User.create!(

  name: "Andrea",
  surname: "Ostrá",
  job: "Horník",
  password: "password",
  email: "ostra@email.cz"
)


acc1 = user1.account
acc2 = user2.account

if acc1 && acc2



  bal1 = 0
  [10000, 5000, 200, 2000, 500].each do |amount|
    Transaction.create!(account: acc1, amount: amount, transaction_type: "deposit", description: "Vklad")
    bal1 += amount
  end

  [1000, 2000, 500].each do |amount|
    Transaction.create!(account: acc1, amount: amount, transaction_type: "withdraw", description: "Výběr")
    bal1 -= amount
  end

  [1500, 300].each do |amount|
    Transaction.create!(account: acc1, amount: amount, transaction_type: "payment", counterparty_number: acc2.account_number, description: "Platba pro Andreu")
    bal1 -= amount
  end
  acc1.update!(balance_CZ: bal1)

  bal2 = 0
  [20000, 500].each do |amount|
    Transaction.create!(account: acc2, amount: amount, transaction_type: "deposit", description: "Vklad")
    bal2 += amount
  end

  Transaction.create!(account: acc2, amount: 1000, transaction_type: "payment", counterparty_number: acc1.account_number, description: "Platba pro Jana")
  bal2 -= 1000
  acc2.update!(balance_CZ: bal2)



  Loan.create!(
    account: acc1,
    amount: 200000,
    interest: 5,
    total_amount: 210000,
    unpayed_amount: 210000,
    status: "approved",
    description: "Rekonstrukce bytu"
  )

  Loan.create!(
    account: acc2,
    amount: 50000,
    interest: 12,
    total_amount: 56000,
    unpayed_amount: 56000,
    status: "pending",
    description: "Nová pračka"
  )

else
  puts "⚠CHYBA"
end
