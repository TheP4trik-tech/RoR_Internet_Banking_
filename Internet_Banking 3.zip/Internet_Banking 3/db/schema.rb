# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.1].define(version: 2026_01_12_221846) do
  create_table "accounts", force: :cascade do |t|
    t.decimal "balance_CZ"
    t.decimal "balance_EUR"
    t.decimal "deposit"
    t.decimal "withdraw"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "account_number"
    t.string "bank_code"
    t.integer "user_id", null: false
    t.index ["user_id"], name: "index_accounts_on_user_id"
  end

  create_table "bankers", force: :cascade do |t|
    t.string "password"
    t.string "email"
    t.string "name"
    t.string "surname"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.index ["email"], name: "index_bankers_on_email", unique: true
    t.index ["reset_password_token"], name: "index_bankers_on_reset_password_token", unique: true
  end

  create_table "bankers_users", id: false, force: :cascade do |t|
    t.integer "banker_id", null: false
    t.integer "user_id", null: false
    t.index ["banker_id", "user_id"], name: "index_bankers_users_on_banker_id_and_user_id"
    t.index ["user_id", "banker_id"], name: "index_bankers_users_on_user_id_and_banker_id"
  end

  create_table "client_managements", force: :cascade do |t|
    t.integer "banker_id", null: false
    t.integer "user_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["banker_id"], name: "index_client_managements_on_banker_id"
    t.index ["user_id"], name: "index_client_managements_on_user_id"
  end

  create_table "loan_payments", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "loans", force: :cascade do |t|
    t.integer "amount"
    t.decimal "interest"
    t.decimal "total_amount"
    t.string "description"
    t.string "status"
    t.decimal "unpayed_amount"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "account_id", null: false
    t.index ["account_id"], name: "index_loans_on_account_id"
  end

  create_table "transactions", force: :cascade do |t|
    t.integer "account_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "counterparty_number"
    t.string "transaction_type"
    t.decimal "amount"
    t.string "description"
    t.index ["account_id"], name: "index_transactions_on_account_id"
  end

  create_table "users", force: :cascade do |t|
    t.string "name"
    t.string "surname"
    t.string "email"
    t.string "job"
    t.boolean "is_risky"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.string "username"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  add_foreign_key "accounts", "users"
  add_foreign_key "client_managements", "bankers"
  add_foreign_key "client_managements", "users"
  add_foreign_key "loans", "accounts"
  add_foreign_key "transactions", "accounts"
end
