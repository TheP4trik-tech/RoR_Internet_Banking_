class TransactionsController < ApplicationController
  before_action :authenticate_user!
  def create
    @account = current_user.account
    @transaction = @account.transactions.build(transaction_params)

    @transaction.counterparty_number = @transaction.counterparty_number.to_s.strip

    @account_to_transfer = Account.find_by(account_number: @transaction.counterparty_number)

    success = false
    error_message = "Neznámá chyba."

    if @transaction.transaction_type == "deposit"
      if @transaction.counterparty_number.present?
        error_message = "Při vkladu nelze přidat příjemce"
      else
      @account.balance_CZ += @transaction.amount
      success = true
      end

    elsif @transaction.transaction_type == "withdraw"
      if @transaction.counterparty_number.present?
      error_message = "Při výběřu nelze přidat příjemce"
      elsif  @account.balance_CZ >= @transaction.amount
        @account.balance_CZ -= @transaction.amount
        success = true
       else
        error_message = "Nedostatečný zůstatek."
      end

    elsif @transaction.transaction_type == "transfer"

      if @account_to_transfer.nil?
        error_message = "Účet '#{@transaction.counterparty_number}' neexistuje."
      elsif @account_to_transfer.id == @account.id
        error_message = "Nemůžete poslat peníze sami sobě."
      elsif @account.balance_CZ < @transaction.amount
        error_message = "Nedostatečný zůstatek."

      else
        @account.balance_CZ -= @transaction.amount
        @account_to_transfer.balance_CZ += @transaction.amount

        @account_to_transfer.transactions.build(
          amount: @transaction.amount,
          transaction_type: "deposit_from",
          counterparty_number: @account.account_number,
          description: @transaction.description,
        )
        success = true
        puts "DEBUG: Podmínky transferu splněny."
      end
    end

    if success && @transaction.save
      @account.save
      @account_to_transfer&.save
      puts "--- TRANSAKCE ULOŽENA ---"
      redirect_to account_transactions_path(@account), notice: "Transakce proběhla úspěšně."
    else
      flash.now[:alert] = error_message
      render :new, status: :unprocessable_entity
    end
  end
  def new
    @account = current_user.account
    @transaction = Transaction.new
  end
  def show
  @transaction = Transaction.find(params[:id])
  end
  def index
    @account = current_user.account
    @pagy, @transactions = pagy(@account.transactions, items: 4)
     @total_withdrawed = current_user.account.transactions.where(transaction_type: ['withdraw']).sum(:amount)

  end
  private
  def transaction_params
    params.require(:transaction).permit(:amount, :counterparty_number, :transaction_type, :description    )
  end

end
