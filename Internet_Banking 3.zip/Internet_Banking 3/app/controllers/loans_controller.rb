class LoansController < ApplicationController
  before_action :authenticate_user!

  def index
    @loans = current_user.account.loans.ordered
  end

  def new
    @loan = Loan.new
  end

  def create
    @loan = current_user.account.loans.build(loan_params)

    if @loan.save
      redirect_to loans_path, notice: "Žádost o půjčku byla odeslána."
    else
      render :new, status: :unprocessable_entity
    end
  end

  private

  def loan_params
    params.require(:loan).permit(:amount, :description)
  end
end

