class AccountsController < ApplicationController

end
