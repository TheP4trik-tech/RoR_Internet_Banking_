class Bankers::LoansController < ApplicationController
  layout "bankers/layouts/application"
  before_action :authenticate_banker!

  def index
    @pagy, @loans = pagy(Loan.all.includes(account: :user).order(created_at: :desc), items: 10)
  end

  def approve
    @loan = Loan.find(params[:id])

    if @loan.status == 'open'
      ActiveRecord::Base.transaction do
        @loan.update!(status: 'accepted')
        @loan.account.balance_CZ += @loan.amount
        @loan.account.save!

        @loan.account.transactions.create!(
          amount: @loan.amount,
          transaction_type: 'deposit',
          description: "Půjčka: #{@loan.description}",
          counterparty_number: 'SmudaBank'
        )
      end
      redirect_to bankers_loans_path, notice: "Půjčka schválena."
    end
  end

  def decline
    @loan = Loan.find(params[:id])
    if @loan.status == 'open'
      @loan.update(status: 'declined')
      redirect_to bankers_loans_path, notice: "Půjčka zamítnuta."
    end
  end
end