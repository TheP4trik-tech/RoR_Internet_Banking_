class HomeController < ApplicationController
  skip_before_action :authenticate_user!, raise: false
  skip_before_action :authenticate_banker!, raise: false
  def index
    if banker_signed_in?

      redirect_to banker_root_path
    else
    end
    end
end
