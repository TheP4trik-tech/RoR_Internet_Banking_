class BankersController < ApplicationController
  layout "bankers/layouts/application"
  before_action :authenticate_banker!

  def send_reset_password_instructions
     false
  end

  def index
    @banker = current_banker

  end

  def accounts
    @q = Account.includes(:user).ransack(params[:q])
    @q.sorts = 'created_at desc' if @q.sorts.empty?

    @pagy, @accounts = pagy(@q.result(distinct: true), items: 6)
  end
  def transactions
    @transactions = Transaction.all
    @pagy, @transactions = pagy(Transaction.all.includes(:account).order(created_at: :desc), items: 6)
  end
  def destroy_user
    User.find(params[:id]).destroy
    redirect_to bankers_accounts_path, notice: "Klient a jeho účet byli smazáni."
  end
  def users
    @pagy, @users = pagy(User.all.includes(:account).order(created_at: :desc), items: 6)
  end






end
