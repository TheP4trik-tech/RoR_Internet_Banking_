class UserMailer < ApplicationMailer
  default from: 'info@smudabank.com'

  def welcome_email
    @user = params[:user]
    @url  = 'http://localhost:3000/users/sign_in'
    mail(to: @user.email, subject: 'Vítejte ve SmudaBank')
  end
end