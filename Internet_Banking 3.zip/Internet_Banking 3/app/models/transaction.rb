class Transaction < ApplicationRecord
  belongs_to :account, dependent: :destroy
  validates :amount , presence: true, numericality: { greater_than: 0 }
  validates :transaction_type, presence: true
  def account_date

    "#{# Source - https://stackoverflow.com/a/29589560
    created_at.strftime("%d.%m.%Y")
    }"
  end

end
