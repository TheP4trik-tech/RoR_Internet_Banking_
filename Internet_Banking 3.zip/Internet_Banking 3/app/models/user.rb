class User < ApplicationRecord
    devise :database_authenticatable, :registerable,
           :recoverable, :rememberable, :validatable
    validates :email, uniqueness: true, presence: true, format:  { with: Devise.email_regexp, message: "is not a valid email address format."}
    validates :name, :surname, :job, :password, presence: true
    has_one :account, dependent: :destroy
    has_many :client_managements, :dependent => :destroy
    has_many :bankers, through: :client_managements
    before_validation :set_is_risky?
    after_create :create_new_account,:assign_banker, :send_welcome_email
    def create_new_account

      account = Account.new(balance_CZ: 0, balance_EUR: 0, user_id: self.id, account_number: assign_account_number,bank_code: 5500 )
      account.save


    end
    def assign_banker

      banker = Banker.first


      if banker
        ClientManagement.create!(user: self, banker: banker )
      end
    end
    def assign_account_number
      last_account = Account.order(:created_at).last
      if last_account.present? && last_account.account_number.present?

         last_account.account_number.next
      else
         "47922940127"
      end
    end

    def set_is_risky?
        case self.job
      when "OSVČ", "Bez Zaměstnání", "Bez Zaměstnání - důchod","Uklížeč","Horník"
        self.is_risky = true
      else
        self.is_risky = false
      end

    end
    def to_s
      "#{name} #{surname}"
    end
    def send_welcome_email
      UserMailer.with(user: self).welcome_email.deliver_now
    end

    def self.ransackable_attributes(auth_object = nil)
      ["created_at", "email", "encrypted_password", "id", "id_value", "is_risky", "job", "name", "remember_created_at", "reset_password_sent_at", "reset_password_token", "surname", "updated_at", "username"]
    end
    def self.ransackable_associations(auth_object = nil)
      ["account", "bankers", "client_managements"]
    end


    private
    def assign_default_banker
      banker = Banker.first
      if banker
        banker.users << self
      end
    end


  end
