class LoanPayment < ApplicationRecord
end
