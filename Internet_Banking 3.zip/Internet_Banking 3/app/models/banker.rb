class Banker < ApplicationRecord
  has_many :client_managements
  has_many :users ,through: :client_managements
  has_many :accounts, through: :users, source: :account
  validates :email, uniqueness: true, format: Devise.email_regexp
  validates :password, length: { within: Devise.password_length }
  validates :name,:surname, presence: true

  # Include default devise_backup modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :rememberable, :validatable


end
