class Loan < ApplicationRecord
  belongs_to :account
  validates :amount, presence: true, numericality: { greater_than: 0 }
  validates :description, presence: true

  scope :ordered, -> { order(created_at: :desc) }

  before_create :set_defaults

  def set_defaults
    self.status = "open"
    self.interest = 10

    self.total_amount = amount * 1.10
    self.unpayed_amount = self.total_amount
  end
end