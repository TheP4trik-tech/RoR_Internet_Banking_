class ClientManagement < ApplicationRecord
  belongs_to :banker
  belongs_to :user
end
