  class Account < ApplicationRecord
    belongs_to :user, dependent: :destroy
    has_many :transactions, dependent: :destroy
    has_many :loans, dependent: :destroy
    validates :balance_CZ, :balance_EUR, numericality: { greater_than_or_equal_to: 0 }, allow_nil: false


    def to_s
      "#{account_number}/#{bank_code}"
    end
    def account_date

      "#{# Source - https://stackoverflow.com/a/29589560
      created_at.strftime("%d.%m.%Y")
      }"
    end
    def self.ransackable_attributes(auth_object = nil)
      ["account_number", "balance_CZ", "balance_EUR", "bank_code", "created_at", "deposit", "id", "id_value", "updated_at", "user_id", "withdraw"]
    end
    def self.ransackable_associations(auth_object = nil)
      ["loans", "transactions", "user"]
    end



  end
