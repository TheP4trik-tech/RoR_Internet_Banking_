Rails.application.routes.draw do
  devise_for :users
  devise_for :bankers
  root "home#index"
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check
  get "banker/index" => "bankers#index", as: :banker_root
  delete 'bankers/users/:id', to: 'bankers#destroy_user', as: :bankers_delete_user
  get "bankers/accounts" => "bankers#accounts", as: :bankers_accounts
  get "bankers/transactions" => "bankers#transactions", as: :banker_transactions
  get "bankers/users" => "bankers#users", as: :bankers_users
  get "user/index" => "users#index", as: :user_root
    resources :accounts, only: [] do
      resources :transactions, only: [:index,:new, :show,:create]
    end
  resources :loans, only: [:index, :new, :create]

  namespace :bankers do
    resources :loans, only: [:index] do
      member do
        post :approve
        post :decline
      end
    end
  end

  end

