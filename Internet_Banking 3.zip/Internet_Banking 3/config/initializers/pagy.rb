require 'pagy/extras/bootstrap'

Pagy::DEFAULT[:items] = 10
Pagy::DEFAULT[:overflow] = :empty_page