require "test_helper"

class BankerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
