require "test_helper"

class LoanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
