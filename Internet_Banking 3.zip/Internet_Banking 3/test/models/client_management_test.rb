require "test_helper"

class ClientManagementTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
